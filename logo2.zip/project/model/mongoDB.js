const { MongoClient, ServerApiVersion } = require('mongodb');
const uri = "mongodb+srv://morshirin23:59daJAH20rHceGRF@flights.piwctub.mongodb.net/?retryWrites=true&w=majority";

// Create a MongoClient with a MongoClientOptions object to set the Stable API version
const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  }
});

async function run() {
  try {
    // Connect the client to the server	(optional starting in v4.7)
    await client.connect();
    // Send a ping to confirm a successful connection
    await client.db("admin").command({ ping: 1 });
    console.log("Pinged your deployment. You successfully connected to MongoDB!");
  } finally {
    // Ensures that the client will close when you finish/error
    await client.close();
  }
}

const getFlight = async () => {
    const client = new MongoClient(uri, { useUnifiedTopology: true });
  
    try {
      await client.connect();
      console.log('Connected to MongoDB Atlas');  
      const database = client.db('flights');
      const collection = database.collection('flight');
      const flight = await collection.find().toArray();
      console.log(flight);
      return flight;
    } catch (error) {
      console.error('Error connecting to MongoDB Atlas:', error);
      throw new Error('Failed to retrieve products from the database');
    } finally {
      await client.close();
    }
};


const getOpinion = async () => {
  const client = new MongoClient(uri, { useUnifiedTopology: true });

  try {
    await client.connect();
    console.log('Connected to MongoDB Atlas');  
    const database = client.db('flights');
    const collection = database.collection('opinion');
    const opinion = await collection.find().toArray();
    console.log(opinion);
    return opinion;
  } catch (error) {
    console.error('Error connecting to MongoDB Atlas:', error);
    throw new Error('Failed to retrieve products from the database');
  } finally {
    await client.close();
  }
};



async function getUser() {
  try {
      await client.connect();
      const database = client.db('flights'); // Change this to your database name
      const collection = database.collection('customer'); // Change this to your collection name
      const users = await collection.find({}).toArray();
      return users;
  } catch (error) {
      console.error('Error fetching user data from the database:', error);
      throw new Error('Failed to fetch user data from the database');
  } finally {
      await client.close();
  }
}





module.exports = {
  getOpinion,
  getFlight,
  getUser

};

run().catch(console.dir);